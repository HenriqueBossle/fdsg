<?php

require_once("../model/Filme.php");

class FilmesController{
    public function cadastrar(){
        $pagina = require_once("../view/cadastrar.php");

        if($_SERVER['REQUEST_METHOD'] === 'POST'){
            $filme = new Filme($_POST["titulo"], $_POST["sinopse"]);
            $filme->salvar();
        }
        return $pagina;
    }

    public function listar(){
        $filme = new Filme(null, null);
        $arrayFilmes = $filme->listar();
        $pagina = require_once("../view/listar.php");

        return $pagina;
    }

    public function editar()
    {
        $id = $_GET['id'];
        $filme = new Filme(null, null);
        $resultado = $filme->buscarPeloId($id);

        $pagina = require_once("../view/editar.php");

        return $pagina;


    }

    public function deletar()
    {
        $id = $_GET['id'];
        $filme = new Filme(null, null);
        $filme->deletar($id);

        header("Location: http://localhost:8081/aula_4/controller/FilmeController.php?action=listar");

        
    }
}


$filmeController = new FilmesController();
$action = $_GET["action"];
$filmeController->$action();



