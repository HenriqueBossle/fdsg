<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
    

<body>
    <?php require_once("navbar.php");
    ?>

    <h1>Lista de filmes</h1>
    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <td>Titulo</td>
                    <td>Sinopse</td>
                    <td>Ações</td>
                </tr>
            </thead>
            
            <tbody>
                <?php foreach($arrayFilmes as $filme): ?>
                <tr>
                    <td><?php echo $filme["titulo"]; ?></td>
                    <td><?php echo $filme["sinopse"]; ?></td>
                    <td>
                        <a href="http://localhost:8081/aula_4/controller/FilmeController.php?action=editar&id=<?php echo $filme["id"];?>" class="btn btn-success">Editar </a>
                        <a href="http://localhost:8081/aula_4/controller/FilmeController.php?action=deletar&id=<?php echo $filme["id"];?>" class="btn btn-danger">Deletar </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            
        </table>
    </div>
    
    
</body>
</html>