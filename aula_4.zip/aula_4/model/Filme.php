<?php

class Filme {
    public ?string $titulo;

    public ?string $sinopse;

    public function __construct(?string $titulo, ?string $sinopse) {
        $this->titulo = $titulo;
        $this->sinopse = $sinopse;
    }

    public function criaConexaoComBanco() {
    
        $host = "mysql";
        $user = "root";
        $pass = "1q2w3e4r5t";
        $db = "db";
        $port = "3306";
    
        $mysqli = new mysqli($host,$user,$pass,$db,$port);
    
        if ($mysqli->connect_errno) {
            echo "Falha: " . $mysqli -> connect_error;
            exit();
      }
      return $mysqli;
    }

    public function salvar()
    {
        $sql = "INSERT into filmes (titulo, sinopse) values ('{$this->titulo}', '{$this->sinopse}')";

        $conn = $this->criaConexaoComBanco();
        if($conn->query($sql) === TRUE) {
            echo "Registro salvo com sucesso";
        } else {
            echo "Erro ao salvar no banco de dados";
        }
    }

    public function listar()
    {
        $conn = $this->criaConexaoComBanco();

        $result = mysqli_query($conn, "select * from filmes");

        $arrayFilmes = [];
        /* fetch associative array */
        while ($row = mysqli_fetch_assoc($result)) {
            $filme = [];
            $filme["titulo"] = $row["titulo"];
            $filme["sinopse"] = $row["sinopse"];
            $filme["id"] = $row["id"];
            $arrayFilmes[] = $filme;
        }

        return $arrayFilmes;
    }

    public function buscarPeloId(int $id)
    {
        $conn = $this->criaConexaoComBanco();
        $resultado = mysqli_query($conn, query: "select * from filmes where id = {$id}");

        return $resultado->fetch_assoc();
    }

    public function deletar(int $id)
    {
        $conn = $this->criaConexaoComBanco();
        $resultado = mysqli_query($conn, query: "delete from filmes where id = {$id}");
    }

}